from flask import Flask, render_template, request, jsonify, session
import sqlite3, os, re, hashlib, io
from datetime import date, timedelta
from collections import defaultdict
from functools import wraps

app = Flask(__name__)
app.secret_key = 'vt2025xk9m'
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'shop.db')

def db():
    c = sqlite3.connect(DB)
    c.row_factory = sqlite3.Row
    return c

def init_db():
    con = db()
    con.executescript('''
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL, email TEXT UNIQUE NOT NULL, password TEXT NOT NULL,
            shop_name TEXT DEFAULT '', shop_address TEXT DEFAULT '',
            shop_category TEXT DEFAULT 'General', phone TEXT DEFAULT '',
            created_at TEXT DEFAULT (date('now'))
        );
        CREATE TABLE IF NOT EXISTS sales (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            product_name TEXT NOT NULL, category TEXT DEFAULT 'General',
            quantity REAL NOT NULL, buying_price REAL DEFAULT 0, selling_price REAL NOT NULL,
            date TEXT NOT NULL, payment_mode TEXT DEFAULT 'Cash',
            customer TEXT DEFAULT '', note TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS expenses (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            title TEXT NOT NULL, amount REAL NOT NULL, category TEXT DEFAULT 'General',
            date TEXT NOT NULL, note TEXT DEFAULT '',
            created_at TEXT DEFAULT (datetime('now'))
        );
        CREATE TABLE IF NOT EXISTS products (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL,
            name TEXT NOT NULL, category TEXT DEFAULT 'General',
            buy_price REAL DEFAULT 0, sell_price REAL DEFAULT 0,
            stock REAL DEFAULT 0, unit TEXT DEFAULT 'pcs',
            UNIQUE(user_id, name)
        );
        CREATE TABLE IF NOT EXISTS batches (
            batch_no TEXT PRIMARY KEY, product TEXT, manufacturer TEXT, expiry TEXT, status TEXT
        );
        CREATE TABLE IF NOT EXISTS batch_checks (
            id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER,
            batch_no TEXT, status TEXT, checked_at TEXT DEFAULT (datetime('now'))
        );
    ''')
    for b in [
        ('BATCH001','Amul Milk 500ml','Amul Dairy','2025-12-31','Genuine'),
        ('BATCH002','Britannia Bread','Britannia','2025-08-15','Genuine'),
        ('BATCH003','SOAP-XYZ-FAKE','Unknown','N/A','Suspicious'),
        ('BATCH004','India Gate Rice 5kg','KRBL','2026-03-01','Genuine'),
        ('BATCH005','OIL-COUNTERFEIT','Unknown','N/A','Suspicious'),
        ('BATCH006','Tata Salt 1kg','Tata Consumer','2026-06-30','Genuine'),
        ('BATCH007','TEA-REPLICATED','Unknown','N/A','Suspicious'),
        ('BATCH008','Nescafe 200g','Nestle India','2025-11-30','Genuine'),
        ('BATCH009','Fortune Oil 1L','Adani Wilmar','2025-09-20','Genuine'),
        ('BATCH010','MDH-ADULTERATED','Unknown','N/A','Suspicious'),
        ('BATCH011','Parle-G 1kg','Parle Products','2025-10-10','Genuine'),
        ('BATCH012','Surf Excel 1kg','HUL','2026-01-15','Genuine'),
    ]:
        con.execute('INSERT OR IGNORE INTO batches VALUES (?,?,?,?,?)', b)
    try:
        con.execute("INSERT OR IGNORE INTO users (name,email,password,shop_name) VALUES (?,?,?,?)",
                    ('Demo User','demo@shop.com', hashlib.sha256(b'demo123').hexdigest(),'Demo Shop'))
    except: pass
    con.commit(); con.close()

def hp(pw): return hashlib.sha256(pw.encode()).hexdigest()
def uid(): return session['uid']
def auth(f):
    @wraps(f)
    def w(*a,**k):
        if 'uid' not in session: return jsonify({'error':'Unauthorized'}),401
        return f(*a,**k)
    return w

@app.route('/')
def index(): return render_template('index.html')

@app.route('/api/me')
def me():
    if 'uid' not in session: return jsonify({'ok':False})
    con=db(); u=con.execute('SELECT * FROM users WHERE id=?',(session['uid'],)).fetchone(); con.close()
    return jsonify({'ok':True,'user':dict(u)}) if u else jsonify({'ok':False})

@app.route('/api/login',methods=['POST'])
def login():
    d=request.json or {}
    con=db(); u=con.execute('SELECT * FROM users WHERE email=? AND password=?',(d.get('email','').lower(),hp(d.get('password','')))).fetchone(); con.close()
    if not u: return jsonify({'error':'Wrong email or password'}),401
    session['uid']=u['id']; return jsonify({'ok':True,'user':dict(u)})

@app.route('/api/signup',methods=['POST'])
def signup():
    d=request.json or {}
    nm=d.get('name','').strip(); em=d.get('email','').strip().lower(); pw=d.get('password','')
    if not nm or not em or not pw: return jsonify({'error':'All fields required'}),400
    if len(pw)<6: return jsonify({'error':'Password min 6 chars'}),400
    con=db()
    try:
        con.execute('INSERT INTO users (name,email,password) VALUES (?,?,?)',(nm,em,hp(pw))); con.commit()
        u=con.execute('SELECT * FROM users WHERE email=?',(em,)).fetchone()
        session['uid']=u['id']; return jsonify({'ok':True,'user':dict(u)})
    except sqlite3.IntegrityError: return jsonify({'error':'Email already registered'}),400
    finally: con.close()

@app.route('/api/logout',methods=['POST'])
def logout(): session.clear(); return jsonify({'ok':True})

@app.route('/api/shop',methods=['POST'])
@auth
def save_shop():
    d=request.json or {}; con=db()
    con.execute('UPDATE users SET shop_name=?,shop_address=?,shop_category=?,phone=? WHERE id=?',
                (d.get('shop_name',''),d.get('shop_address',''),d.get('shop_category','General'),d.get('phone',''),uid()))
    con.commit(); u=con.execute('SELECT * FROM users WHERE id=?',(uid(),)).fetchone(); con.close()
    return jsonify({'ok':True,'user':dict(u)})

@app.route('/api/sales',methods=['GET'])
@auth
def get_sales():
    q=request.args.get('q',''); con=db()
    if q: rows=con.execute("SELECT * FROM sales WHERE user_id=? AND product_name LIKE ? ORDER BY date DESC,id DESC LIMIT 500",(uid(),f'%{q}%')).fetchall()
    else: rows=con.execute("SELECT * FROM sales WHERE user_id=? ORDER BY date DESC,id DESC LIMIT 500",(uid(),)).fetchall()
    con.close(); return jsonify([dict(r) for r in rows])

@app.route('/api/sales',methods=['POST'])
@auth
def add_sale():
    d=request.json or {}
    if not d.get('product_name') or not d.get('quantity') or d.get('selling_price') is None:
        return jsonify({'error':'Missing fields'}),400
    con=db()
    cur=con.execute('INSERT INTO sales (user_id,product_name,category,quantity,buying_price,selling_price,date,payment_mode,customer,note) VALUES (?,?,?,?,?,?,?,?,?,?)',
        (uid(),str(d['product_name']).strip(),d.get('category','General'),float(d['quantity']),
         float(d.get('buying_price',0)),float(d['selling_price']),d.get('date',str(date.today())),
         d.get('payment_mode','Cash'),d.get('customer',''),d.get('note','')))
    con.commit()
    try:
        con.execute('INSERT INTO products (user_id,name,category,buy_price,sell_price) VALUES (?,?,?,?,?) ON CONFLICT(user_id,name) DO UPDATE SET buy_price=excluded.buy_price,sell_price=excluded.sell_price,category=excluded.category',
                    (uid(),str(d['product_name']).strip(),d.get('category','General'),float(d.get('buying_price',0)),float(d['selling_price'])))
        con.commit()
    except: pass
    sale=con.execute('SELECT * FROM sales WHERE id=?',(cur.lastrowid,)).fetchone(); con.close()
    return jsonify({'ok':True,'sale':dict(sale)})

@app.route('/api/sales/<int:sid>',methods=['PUT'])
@auth
def update_sale(sid):
    d=request.json or {}; con=db()
    con.execute('UPDATE sales SET product_name=?,category=?,quantity=?,buying_price=?,selling_price=?,date=?,payment_mode=?,note=? WHERE id=? AND user_id=?',
                (d.get('product_name'),d.get('category','General'),float(d.get('quantity',0)),float(d.get('buying_price',0)),float(d.get('selling_price',0)),d.get('date'),d.get('payment_mode','Cash'),d.get('note',''),sid,uid()))
    con.commit(); con.close(); return jsonify({'ok':True})

@app.route('/api/sales/<int:sid>',methods=['DELETE'])
@auth
def del_sale(sid):
    con=db(); con.execute('DELETE FROM sales WHERE id=? AND user_id=?',(sid,uid())); con.commit(); con.close()
    return jsonify({'ok':True})

@app.route('/api/expenses',methods=['GET'])
@auth
def get_expenses():
    con=db(); rows=con.execute('SELECT * FROM expenses WHERE user_id=? ORDER BY date DESC,id DESC LIMIT 200',(uid(),)).fetchall(); con.close()
    return jsonify([dict(r) for r in rows])

@app.route('/api/expenses',methods=['POST'])
@auth
def add_expense():
    d=request.json or {}
    if not d.get('title') or not d.get('amount'): return jsonify({'error':'Title and amount required'}),400
    con=db()
    cur=con.execute('INSERT INTO expenses (user_id,title,amount,category,date,note) VALUES (?,?,?,?,?,?)',
                    (uid(),d['title'].strip(),float(d['amount']),d.get('category','General'),d.get('date',str(date.today())),d.get('note','')))
    con.commit(); e=con.execute('SELECT * FROM expenses WHERE id=?',(cur.lastrowid,)).fetchone(); con.close()
    return jsonify({'ok':True,'expense':dict(e)})

@app.route('/api/expenses/<int:eid>',methods=['DELETE'])
@auth
def del_expense(eid):
    con=db(); con.execute('DELETE FROM expenses WHERE id=? AND user_id=?',(eid,uid())); con.commit(); con.close()
    return jsonify({'ok':True})

@app.route('/api/products',methods=['GET'])
@auth
def get_products():
    con=db(); rows=con.execute('SELECT * FROM products WHERE user_id=? ORDER BY name',(uid(),)).fetchall(); con.close()
    return jsonify([dict(r) for r in rows])

@app.route('/api/analytics')
@auth
def analytics():
    con=db()
    sales=[dict(r) for r in con.execute('SELECT * FROM sales WHERE user_id=?',(uid(),)).fetchall()]
    exps=[dict(r) for r in con.execute('SELECT * FROM expenses WHERE user_id=?',(uid(),)).fetchall()]
    con.close()
    today_s=str(date.today()); this_m=today_s[:7]
    last_m=str((date.today().replace(day=1)-timedelta(days=1)))[:7]
    def rev(r): return sum(x['selling_price']*x['quantity'] for x in r)
    def cost(r): return sum(x['buying_price']*x['quantity'] for x in r)
    def prof(r): return rev(r)-cost(r)
    tod=[r for r in sales if r['date']==today_s]
    this_ms=[r for r in sales if r['date'].startswith(this_m)]
    last_ms=[r for r in sales if r['date'].startswith(last_m)]
    tr=rev(sales); tp=prof(sales); te=sum(e['amount'] for e in exps)
    g=(rev(this_ms)-rev(last_ms))/rev(last_ms)*100 if rev(last_ms)>0 else 0
    daily=defaultdict(lambda:{'rev':0.0,'prof':0.0,'cnt':0,'exp':0.0})
    for r in sales:
        daily[r['date']]['rev']+=r['selling_price']*r['quantity']
        daily[r['date']]['prof']+=(r['selling_price']-r['buying_price'])*r['quantity']
        daily[r['date']]['cnt']+=1
    for e in exps: daily[e['date']]['exp']+=e['amount']
    trend=[{'date':str(date.today()-timedelta(days=i)),'rev':round(daily[str(date.today()-timedelta(days=i))]['rev'],2),'prof':round(daily[str(date.today()-timedelta(days=i))]['prof'],2),'exp':round(daily[str(date.today()-timedelta(days=i))]['exp'],2)} for i in range(29,-1,-1)]
    prods=defaultdict(lambda:{'rev':0.0,'prof':0.0,'qty':0.0})
    for r in sales:
        prods[r['product_name']]['rev']+=r['selling_price']*r['quantity']
        prods[r['product_name']]['prof']+=(r['selling_price']-r['buying_price'])*r['quantity']
        prods[r['product_name']]['qty']+=r['quantity']
    cats=defaultdict(float)
    for r in sales: cats[r.get('category','General')]+=r['selling_price']*r['quantity']
    pays=defaultdict(float)
    for r in sales: pays[r.get('payment_mode','Cash')]+=r['selling_price']*r['quantity']
    ad=len(set(r['date'] for r in sales)) or 1
    return jsonify({'total_rev':round(tr,2),'total_prof':round(tp,2),'total_exp':round(te,2),'net_profit':round(tp-te,2),'today_rev':round(rev(tod),2),'today_prof':round(prof(tod),2),'today_cnt':len(tod),'total_cnt':len(sales),'this_month_rev':round(rev(this_ms),2),'growth':round(g,1),'margin':round(tp/tr*100,1) if tr>0 else 0,'avg_daily':round(tr/ad,2),'today_recorded':len(tod)>0,'trend':trend,'products':{k:{kk:round(vv,2) if isinstance(vv,float) else vv for kk,vv in v.items()} for k,v in prods.items()},'categories':dict(cats),'payments':dict(pays),'today_exp':round(sum(e['amount'] for e in exps if e['date']==today_s),2)})

@app.route('/api/batch',methods=['POST'])
@auth
def verify_batch():
    bn=(request.json or {}).get('batch_no','').strip().upper()
    if not bn: return jsonify({'error':'Required'}),400
    con=db(); row=con.execute('SELECT * FROM batches WHERE batch_no=?',(bn,)).fetchone()
    status=row['status'] if row else 'Unknown'
    con.execute('INSERT INTO batch_checks (user_id,batch_no,status) VALUES (?,?,?)',(uid(),bn,status))
    con.commit(); con.close()
    return jsonify({'found':bool(row),**(dict(row) if row else {'batch_no':bn,'status':'Unknown','product':None})})

@app.route('/api/batch-history')
@auth
def batch_hist():
    con=db(); rows=con.execute('SELECT * FROM batch_checks WHERE user_id=? ORDER BY checked_at DESC LIMIT 20',(uid(),)).fetchall(); con.close()
    return jsonify([dict(r) for r in rows])

# ─── REAL OCR WITH TESSERACT ──────────────────────────────────────────────
def preprocess(img):
    from PIL import Image, ImageEnhance, ImageFilter, ImageOps
    img = img.convert('RGB')
    w,h = img.size
    if max(w,h) < 1400:
        s = 1400/max(w,h)
        img = img.resize((int(w*s),int(h*s)), Image.LANCZOS)
    g = img.convert('L')
    g = ImageEnhance.Contrast(g).enhance(2.5)
    g = ImageEnhance.Sharpness(g).enhance(2.0)
    g = g.filter(ImageFilter.GaussianBlur(0.6))
    hist = g.histogram(); total = sum(hist); cum = 0; thresh = 128
    for i,c in enumerate(hist):
        cum += c
        if cum >= total*0.45: thresh=i; break
    thresh = max(90, min(thresh, 210))
    b = g.point(lambda p: 255 if p > thresh else 0,'1').convert('L')
    b = b.filter(ImageFilter.MaxFilter(3))
    avg = sum(b.getdata())/len(b.getdata())
    if avg < 127: b = ImageOps.invert(b)
    return b

def tesseract_ocr(img):
    import pytesseract
    processed = preprocess(img)
    best = ('', 0)
    for psm in [6, 4, 3, 11]:
        try:
            raw = pytesseract.image_to_string(processed, config=f'--oem 3 --psm {psm}', lang='eng')
            score = sum(1 for l in raw.splitlines() if re.search(r'[a-zA-Z]',l) and re.search(r'\d',l))
            if score > best[1]: best = (raw, score)
        except: pass
    # also try rotations if low score
    if best[1] < 2:
        for angle in [90,-90,180]:
            try:
                rot = img.rotate(angle, expand=True)
                p2 = preprocess(rot)
                raw = pytesseract.image_to_string(p2, config='--oem 3 --psm 6', lang='eng')
                score = sum(1 for l in raw.splitlines() if re.search(r'[a-zA-Z]',l) and re.search(r'\d',l))
                if score > best[1]: best = (raw, score)
            except: pass
    return best[0]

def parse_lines(text):
    SKIP = re.compile(r'^(product|item|sl|s\.?no|no\.?|date|total|qty|quantity|price|rate|rs\.?|inr|mrp|sub|grand|bill|invoice|shop|receipt|page|#)',re.I)
    FIX = {ord('O'):'0',ord('l'):'1',ord('I'):'1',ord('S'):'5',ord('B'):'8',ord('G'):'6',ord(','):'.'}
    def num(s):
        s = re.sub(r'[^\d.,OlISBG]','',s).translate(FIX)
        try: return round(float(s),2) if s else None
        except: return None
    results=[]; seen=set()
    for line in text.splitlines():
        line = line.strip()
        if not line: continue
        stripped = re.sub(r'^[\d\s\.\)\-]+','',line).strip()
        if SKIP.match(stripped): continue
        clean = re.sub(r'^\d{1,3}[\.\)\s]+','',line).strip()
        clean = re.sub(r'[|,\t]',' ',clean)
        clean = re.sub(r'[₹Rs\.INR]','',clean,flags=re.I)
        nums = [num(m) for m in re.findall(r'\b\d+(?:[.,]\d+)?\b', clean)]
        nums = [n for n in nums if n and n > 0]
        if len(nums) < 2: continue
        nm = re.match(r'^([^\d₹]+)', clean)
        if not nm: continue
        name = re.sub(r'[-:\.]+$','',nm.group(1)).strip()
        name = re.sub(r'\s*(pcs?|nos?|units?|kgs?|ltrs?|ml|gm?s?|kg|ltr|pack)\.?\s*$','',name,flags=re.I).strip()
        name = re.sub(r'\s{2,}',' ',name).strip()
        if len(name)<2 or not re.search(r'[a-zA-Z]',name): continue
        working = nums[:]
        if len(working)>=3 and working[0]==int(working[0]) and 1<=working[0]<=200: working=working[1:]
        if len(working)<2: continue
        qty,price = working[0],working[1]
        if qty<=0 or qty>99999 or price<=0 or price>999999: continue
        key=name.lower()
        if key in seen: continue
        seen.add(key)
        results.append({'product_name':name,'quantity':qty,'selling_price':price,'buying_price':round(price*0.72,2),'category':'General'})
    return results

@app.route('/api/ocr',methods=['POST'])
@auth
def ocr():
    text = request.form.get('text','').strip()
    source = 'text'; err = None
    if 'file' in request.files:
        raw = request.files['file'].read()
        if raw:
            source = 'image'
            try:
                from PIL import Image
                pil = Image.open(io.BytesIO(raw)); pil.load()
                text = tesseract_ocr(pil)
            except Exception as e: err = str(e)
    parsed = parse_lines(text)
    return jsonify({'ok':True,'parsed':parsed,'raw':text,'count':len(parsed),'source':source,'error':err})

if __name__ == '__main__':
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    init_db()
    print('\n  Veriscope Trade v4  |  http://localhost:5050')
    print('  Demo: demo@shop.com / demo123\n')
    app.run(debug=True, port=5050, use_reloader=False)
